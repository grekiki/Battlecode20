package grekiki3;

import battlecode.common.RobotController;

public class refinery extends robot{

	public refinery(RobotController rc){
		super(rc);
		
	}

	@Override public void init(){
		

	}

	@Override public void precompute(){
		

	}

	@Override public void runTurn(){
		

	}

	@Override public void postcompute(){
		

	}

}
