package grekiki3;

import battlecode.common.RobotController;

public class vaporator extends robot{

	public vaporator(RobotController rc){
		super(rc);
		
	}

	@Override public void init(){
		

	}

	@Override public void precompute(){
		

	}

	@Override public void runTurn(){
		

	}

	@Override public void postcompute(){
		

	}

}
